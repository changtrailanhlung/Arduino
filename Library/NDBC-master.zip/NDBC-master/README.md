# NDBC
National Data Buoy Center Wind &amp; Wave Watcher
Display current wind and weather info from the NDBC
to an lcd display and use a NodeMCU to retrieve the information
from the NDBC website
