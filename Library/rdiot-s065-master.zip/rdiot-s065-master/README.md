# rdiot-s065
GP2Y1010AU0F Compact Optical Dust Sensor + Adapter  (GP2Y1010AU0F,DFR0280) [S065] : http://rdiot.tistory.com/114

![alt text](http://cfile28.uf.tistory.com/image/21182D3F57D6650D302CB5)
